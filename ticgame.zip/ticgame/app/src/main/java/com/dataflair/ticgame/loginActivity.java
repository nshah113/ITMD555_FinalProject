package com.dataflair.ticgame;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class loginActivity extends AppCompatActivity {
    public static final String USERNAME = "npshah92";
    public static final String PASSWORD = "Nikita17";
    public static final int CHANCES = 3;

    Button loginbtn;

    TextView textViewProblems;
    EditText username;
    EditText password;

    @SuppressLint("WrongViewCast")
    public void populateComponents() {
        loginbtn = findViewById(R.id.loginbtn);
        textViewProblems = findViewById(R.id.textViewProblems);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final Integer[] tries = {CHANCES};
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        populateComponents();
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (credsValid()) {
                    Toast.makeText(getApplicationContext(), "Good Luck!!", Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(myIntent);
                } else {
                    textViewProblems.setText(String.format("Wrong Credentials. \n" + "%d chances left.", tries[0]));
                    tries[0] = tries[0] - 1;
                }
                if (tries[0] <= 0) {
                    finish();
                }
            }
        });
    }
    private void populateLogin() {
        username.setText(USERNAME);
        password.setText(PASSWORD);
    }
    private String getUsername() {
        return username.getText().toString();
    }
    private String getPassword() {
        return password.getText().toString();
    }
    public boolean credsValid() {
        return (getUsername().equals(USERNAME) && getPassword().equals(PASSWORD));
    }
}
